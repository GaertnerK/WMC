package at.htlgkr.gaert;

public interface Converter {
    public String getConverter(float f);
}
