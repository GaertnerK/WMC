package at.htlgkr.gaert;

public interface IDashboard {
    String displayableTemperature();
    String displayablePressure();
    String displayableSpeed();
    String displayableTime();
}
