package at.htlgkr.gaert;

public interface Time {
    public String getTime(String t);
}
